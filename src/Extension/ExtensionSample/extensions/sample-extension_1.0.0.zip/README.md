# 示例扩展 / Sample Extension

## 版本 / Version: 1.0.0

### 描述 / Description
这是一个演示用的示例扩展 / This is a sample extension for demonstration

### 发布者 / Publisher
GeneralUpdate Team

### 许可证 / License
MIT

### 支持的平台 / Supported Platforms
All

### 兼容性 / Compatibility
- 最小主机版本 / Min Host Version: 1.0.0
- 最大主机版本 / Max Host Version: 2.0.0

### 分类 / Categories
Tools,Development

---

## 安装 / Installation
此扩展包与 GeneralUpdate.Extension 主机兼容。
This extension package is compatible with GeneralUpdate.Extension host.

生成时间 / Generated: 2026-02-12 10:45:46 UTC
